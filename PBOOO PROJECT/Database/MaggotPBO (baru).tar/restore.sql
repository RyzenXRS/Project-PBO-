--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MaggotPBO";
--
-- Name: MaggotPBO; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MaggotPBO" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en-US';


ALTER DATABASE "MaggotPBO" OWNER TO postgres;

\connect "MaggotPBO"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: role_user; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.role_user AS ENUM (
    'admin',
    'pembudidaya',
    'supplier'
);


ALTER TYPE public.role_user OWNER TO postgres;

--
-- Name: status_stok; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_stok AS ENUM (
    'tersedia',
    'habis'
);


ALTER TYPE public.status_stok OWNER TO postgres;

--
-- Name: status_transaksi; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_transaksi AS ENUM (
    'diproses',
    'dikirim',
    'diterima',
    'dibatalkan'
);


ALTER TYPE public.status_transaksi OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    id_admin integer NOT NULL,
    nama_admin character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    no_telp character varying(15) NOT NULL,
    password character varying(20) NOT NULL,
    alamat text NOT NULL,
    id_penjual integer,
    id_pembeli integer
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: detail_transaksi_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_transaksi_maggot (
    id_detail_transaksi_maggot integer NOT NULL,
    id_maggot integer NOT NULL,
    id_transaksi_maggot integer NOT NULL
);


ALTER TABLE public.detail_transaksi_maggot OWNER TO postgres;

--
-- Name: detail_transaksi_sampah; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_transaksi_sampah (
    id_detail_transaksi_sampah integer NOT NULL,
    id_sampah_organik integer NOT NULL,
    id_transaksi_sampah integer NOT NULL
);


ALTER TABLE public.detail_transaksi_sampah OWNER TO postgres;

--
-- Name: id_maggot_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id_maggot_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.id_maggot_seq OWNER TO postgres;

--
-- Name: id_pembeli_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id_pembeli_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.id_pembeli_seq OWNER TO postgres;

--
-- Name: id_penjual_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id_penjual_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.id_penjual_seq OWNER TO postgres;

--
-- Name: maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maggot (
    id_maggot integer DEFAULT nextval('public.id_maggot_seq'::regclass) NOT NULL,
    jenis_maggot character varying(30) NOT NULL,
    harga_per_kg numeric(10,2) DEFAULT 0 NOT NULL,
    id_penjual integer NOT NULL,
    CONSTRAINT harga_per_kg CHECK ((harga_per_kg >= (0)::numeric)),
    CONSTRAINT harga_per_kg_m CHECK ((harga_per_kg >= (0)::numeric))
);


ALTER TABLE public.maggot OWNER TO postgres;

--
-- Name: pembayaran_ewallet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pembayaran_ewallet (
    id_ewallet integer NOT NULL,
    nomor_ewallet character varying(20) NOT NULL,
    jenis_ewallet character varying(20) NOT NULL
);


ALTER TABLE public.pembayaran_ewallet OWNER TO postgres;

--
-- Name: pembayaran_ewallet_id_ewallet_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pembayaran_ewallet_id_ewallet_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pembayaran_ewallet_id_ewallet_seq OWNER TO postgres;

--
-- Name: pembayaran_ewallet_id_ewallet_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pembayaran_ewallet_id_ewallet_seq OWNED BY public.pembayaran_ewallet.id_ewallet;


--
-- Name: pembeli; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pembeli (
    id_pembeli integer DEFAULT nextval('public.id_pembeli_seq'::regclass) NOT NULL,
    nama_pembeli character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    no_telp character varying(15) NOT NULL,
    password character varying(20) NOT NULL,
    alamat text NOT NULL
);


ALTER TABLE public.pembeli OWNER TO postgres;

--
-- Name: penjual; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.penjual (
    id_penjual integer DEFAULT nextval('public.id_penjual_seq'::regclass) NOT NULL,
    nama_penjual character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    no_telp character varying(15) NOT NULL,
    password character varying(20) NOT NULL,
    alamat text NOT NULL
);


ALTER TABLE public.penjual OWNER TO postgres;

--
-- Name: sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sampah_organik (
    id_sampah_organik integer NOT NULL,
    jenis_sampah character varying(30) NOT NULL,
    harga_per_kg numeric(5,3) DEFAULT 0 NOT NULL,
    id_pembeli integer NOT NULL,
    nama_sampah character varying(100),
    CONSTRAINT harga_per_kg CHECK ((harga_per_kg >= (0)::numeric)),
    CONSTRAINT harga_per_kg_so CHECK ((harga_per_kg >= (0)::numeric))
);


ALTER TABLE public.sampah_organik OWNER TO postgres;

--
-- Name: stok_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok_maggot (
    id_stok_maggot integer NOT NULL,
    id_maggot integer NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    tanggal_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.status_stok NOT NULL,
    deskripsi text,
    id_penjual integer,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_sm CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.stok_maggot OWNER TO postgres;

--
-- Name: stok_sampah_organik_id_stok_sampah_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stok_sampah_organik_id_stok_sampah_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stok_sampah_organik_id_stok_sampah_seq OWNER TO postgres;

--
-- Name: stok_sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok_sampah_organik (
    id_stok_sampah integer DEFAULT nextval('public.stok_sampah_organik_id_stok_sampah_seq'::regclass) NOT NULL,
    id_sampah_organik integer NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    tanggal_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.status_stok NOT NULL,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_sso CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.stok_sampah_organik OWNER TO postgres;

--
-- Name: transaksi_maggot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi_maggot (
    id_transaksi_maggot integer NOT NULL,
    tanggal timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_pembeli_maggot integer NOT NULL,
    id_maggot integer NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    deskripsi text,
    status public.status_transaksi DEFAULT 'diproses'::public.status_transaksi NOT NULL,
    id_ewallet integer,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_tm CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.transaksi_maggot OWNER TO postgres;

--
-- Name: transaksi_sampah_organik; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi_sampah_organik (
    id_transaksi_sampah integer NOT NULL,
    tanggal timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_pembeli_sampah integer NOT NULL,
    id_sampah_organik integer NOT NULL,
    jumlah_kg integer DEFAULT 0 NOT NULL,
    deskripsi text,
    status public.status_transaksi DEFAULT 'diproses'::public.status_transaksi NOT NULL,
    id_ewallet integer,
    CONSTRAINT jumlah_kg CHECK ((jumlah_kg >= 0)),
    CONSTRAINT jumlah_kg_tso CHECK ((jumlah_kg >= 0))
);


ALTER TABLE public.transaksi_sampah_organik OWNER TO postgres;

--
-- Name: pembayaran_ewallet id_ewallet; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran_ewallet ALTER COLUMN id_ewallet SET DEFAULT nextval('public.pembayaran_ewallet_id_ewallet_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin (id_admin, nama_admin, username, no_telp, password, alamat, id_penjual, id_pembeli) FROM stdin;
\.
COPY public.admin (id_admin, nama_admin, username, no_telp, password, alamat, id_penjual, id_pembeli) FROM '$$PATH$$/5016.dat';

--
-- Data for Name: detail_transaksi_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_transaksi_maggot (id_detail_transaksi_maggot, id_maggot, id_transaksi_maggot) FROM stdin;
\.
COPY public.detail_transaksi_maggot (id_detail_transaksi_maggot, id_maggot, id_transaksi_maggot) FROM '$$PATH$$/5017.dat';

--
-- Data for Name: detail_transaksi_sampah; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_transaksi_sampah (id_detail_transaksi_sampah, id_sampah_organik, id_transaksi_sampah) FROM stdin;
\.
COPY public.detail_transaksi_sampah (id_detail_transaksi_sampah, id_sampah_organik, id_transaksi_sampah) FROM '$$PATH$$/5018.dat';

--
-- Data for Name: maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maggot (id_maggot, jenis_maggot, harga_per_kg, id_penjual) FROM stdin;
\.
COPY public.maggot (id_maggot, jenis_maggot, harga_per_kg, id_penjual) FROM '$$PATH$$/5019.dat';

--
-- Data for Name: pembayaran_ewallet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pembayaran_ewallet (id_ewallet, nomor_ewallet, jenis_ewallet) FROM stdin;
\.
COPY public.pembayaran_ewallet (id_ewallet, nomor_ewallet, jenis_ewallet) FROM '$$PATH$$/5032.dat';

--
-- Data for Name: pembeli; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pembeli (id_pembeli, nama_pembeli, username, no_telp, password, alamat) FROM stdin;
\.
COPY public.pembeli (id_pembeli, nama_pembeli, username, no_telp, password, alamat) FROM '$$PATH$$/5020.dat';

--
-- Data for Name: penjual; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.penjual (id_penjual, nama_penjual, username, no_telp, password, alamat) FROM stdin;
\.
COPY public.penjual (id_penjual, nama_penjual, username, no_telp, password, alamat) FROM '$$PATH$$/5021.dat';

--
-- Data for Name: sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sampah_organik (id_sampah_organik, jenis_sampah, harga_per_kg, id_pembeli, nama_sampah) FROM stdin;
\.
COPY public.sampah_organik (id_sampah_organik, jenis_sampah, harga_per_kg, id_pembeli, nama_sampah) FROM '$$PATH$$/5022.dat';

--
-- Data for Name: stok_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stok_maggot (id_stok_maggot, id_maggot, jumlah_kg, tanggal_update, status, deskripsi, id_penjual) FROM stdin;
\.
COPY public.stok_maggot (id_stok_maggot, id_maggot, jumlah_kg, tanggal_update, status, deskripsi, id_penjual) FROM '$$PATH$$/5023.dat';

--
-- Data for Name: stok_sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stok_sampah_organik (id_stok_sampah, id_sampah_organik, jumlah_kg, tanggal_update, status) FROM stdin;
\.
COPY public.stok_sampah_organik (id_stok_sampah, id_sampah_organik, jumlah_kg, tanggal_update, status) FROM '$$PATH$$/5024.dat';

--
-- Data for Name: transaksi_maggot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi_maggot (id_transaksi_maggot, tanggal, id_pembeli_maggot, id_maggot, jumlah_kg, deskripsi, status, id_ewallet) FROM stdin;
\.
COPY public.transaksi_maggot (id_transaksi_maggot, tanggal, id_pembeli_maggot, id_maggot, jumlah_kg, deskripsi, status, id_ewallet) FROM '$$PATH$$/5025.dat';

--
-- Data for Name: transaksi_sampah_organik; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi_sampah_organik (id_transaksi_sampah, tanggal, id_pembeli_sampah, id_sampah_organik, jumlah_kg, deskripsi, status, id_ewallet) FROM stdin;
\.
COPY public.transaksi_sampah_organik (id_transaksi_sampah, tanggal, id_pembeli_sampah, id_sampah_organik, jumlah_kg, deskripsi, status, id_ewallet) FROM '$$PATH$$/5026.dat';

--
-- Name: id_maggot_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id_maggot_seq', 1, false);


--
-- Name: id_pembeli_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id_pembeli_seq', 1, true);


--
-- Name: id_penjual_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id_penjual_seq', 1, true);


--
-- Name: pembayaran_ewallet_id_ewallet_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pembayaran_ewallet_id_ewallet_seq', 13, true);


--
-- Name: stok_sampah_organik_id_stok_sampah_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stok_sampah_organik_id_stok_sampah_seq', 10, true);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id_admin);


--
-- Name: detail_transaksi_maggot detail_transaksi_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT detail_transaksi_maggot_pkey PRIMARY KEY (id_detail_transaksi_maggot);


--
-- Name: detail_transaksi_sampah detail_transaksi_sampah_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT detail_transaksi_sampah_pkey PRIMARY KEY (id_detail_transaksi_sampah);


--
-- Name: maggot maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maggot
    ADD CONSTRAINT maggot_pkey PRIMARY KEY (id_maggot);


--
-- Name: pembayaran_ewallet pembayaran_ewallet_nomor_ewallet_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran_ewallet
    ADD CONSTRAINT pembayaran_ewallet_nomor_ewallet_key UNIQUE (nomor_ewallet);


--
-- Name: pembayaran_ewallet pembayaran_ewallet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran_ewallet
    ADD CONSTRAINT pembayaran_ewallet_pkey PRIMARY KEY (id_ewallet);


--
-- Name: pembeli pembeli_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembeli
    ADD CONSTRAINT pembeli_pkey PRIMARY KEY (id_pembeli);


--
-- Name: penjual penjual_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.penjual
    ADD CONSTRAINT penjual_pkey PRIMARY KEY (id_penjual);


--
-- Name: sampah_organik sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sampah_organik
    ADD CONSTRAINT sampah_organik_pkey PRIMARY KEY (id_sampah_organik);


--
-- Name: stok_maggot stok_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_maggot
    ADD CONSTRAINT stok_maggot_pkey PRIMARY KEY (id_stok_maggot);


--
-- Name: stok_sampah_organik stok_sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_sampah_organik
    ADD CONSTRAINT stok_sampah_organik_pkey PRIMARY KEY (id_stok_sampah);


--
-- Name: transaksi_maggot transaksi_maggot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT transaksi_maggot_pkey PRIMARY KEY (id_transaksi_maggot);


--
-- Name: transaksi_sampah_organik transaksi_sampah_organik_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT transaksi_sampah_organik_pkey PRIMARY KEY (id_transaksi_sampah);


--
-- Name: detail_transaksi_maggot fk_detail_maggot_magg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT fk_detail_maggot_magg FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: detail_transaksi_sampah fk_detail_sampah_sampah; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT fk_detail_sampah_sampah FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- Name: detail_transaksi_sampah fk_detail_transaksi_sampah_transaksi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_sampah
    ADD CONSTRAINT fk_detail_transaksi_sampah_transaksi FOREIGN KEY (id_transaksi_sampah) REFERENCES public.transaksi_sampah_organik(id_transaksi_sampah);


--
-- Name: admin fk_id_pembeli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT fk_id_pembeli FOREIGN KEY (id_pembeli) REFERENCES public.pembeli(id_pembeli);


--
-- Name: admin fk_id_penjual; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT fk_id_penjual FOREIGN KEY (id_penjual) REFERENCES public.penjual(id_penjual);


--
-- Name: maggot fk_maggot_penjual; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maggot
    ADD CONSTRAINT fk_maggot_penjual FOREIGN KEY (id_penjual) REFERENCES public.penjual(id_penjual);


--
-- Name: sampah_organik fk_sampah_organik_pembeli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sampah_organik
    ADD CONSTRAINT fk_sampah_organik_pembeli FOREIGN KEY (id_pembeli) REFERENCES public.pembeli(id_pembeli);


--
-- Name: stok_maggot fk_stok_maggot_maggot; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_maggot
    ADD CONSTRAINT fk_stok_maggot_maggot FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: stok_maggot fk_stok_penjual; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_maggot
    ADD CONSTRAINT fk_stok_penjual FOREIGN KEY (id_penjual) REFERENCES public.penjual(id_penjual) ON DELETE CASCADE;


--
-- Name: stok_sampah_organik fk_stok_sampah_sampah; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok_sampah_organik
    ADD CONSTRAINT fk_stok_sampah_sampah FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- Name: detail_transaksi_maggot fk_transaksi_maggot; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_transaksi_maggot
    ADD CONSTRAINT fk_transaksi_maggot FOREIGN KEY (id_transaksi_maggot) REFERENCES public.transaksi_maggot(id_transaksi_maggot);


--
-- Name: transaksi_maggot fk_transaksi_maggot_maggot; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT fk_transaksi_maggot_maggot FOREIGN KEY (id_maggot) REFERENCES public.maggot(id_maggot);


--
-- Name: transaksi_maggot fk_transaksi_maggot_pembeli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT fk_transaksi_maggot_pembeli FOREIGN KEY (id_pembeli_maggot) REFERENCES public.pembeli(id_pembeli);


--
-- Name: transaksi_sampah_organik fk_transaksi_sampah_organik_penjual; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT fk_transaksi_sampah_organik_penjual FOREIGN KEY (id_pembeli_sampah) REFERENCES public.penjual(id_penjual);


--
-- Name: transaksi_sampah_organik fk_transaksi_sampah_organik_sampah; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT fk_transaksi_sampah_organik_sampah FOREIGN KEY (id_sampah_organik) REFERENCES public.sampah_organik(id_sampah_organik);


--
-- Name: transaksi_maggot transaksi_maggot_id_ewallet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_maggot
    ADD CONSTRAINT transaksi_maggot_id_ewallet_fkey FOREIGN KEY (id_ewallet) REFERENCES public.pembayaran_ewallet(id_ewallet) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transaksi_sampah_organik transaksi_sampah_organik_id_ewallet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi_sampah_organik
    ADD CONSTRAINT transaksi_sampah_organik_id_ewallet_fkey FOREIGN KEY (id_ewallet) REFERENCES public.pembayaran_ewallet(id_ewallet) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

